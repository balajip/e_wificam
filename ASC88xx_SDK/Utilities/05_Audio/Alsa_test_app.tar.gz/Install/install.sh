#!bin/sh

rmmod i2c_gpio
rmmod i2c_algo_bit

mount_as_tmpfs /lib
mount_as_tmpfs /etc

cp lib/libasound.so.2 /lib/
mkdir /etc/ALSA
cp ALSA/alsa.conf /etc/ALSA/

insmod drivers/i2c/i2c-algo-bit.ko
insmod drivers/i2c/i2c-gpio.ko bus_num=2 scl0=6 sda0=7 scl1=12 sda1=13

#cd $DRIVER_PATH
sh snddevices
insmod drivers/NVP1114A_AUDIO.ko CodecNum=2

