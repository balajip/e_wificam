/*

This example reads standard from input and writes
to the default PCM device for 5 seconds of data.

*/

#include <alsa/asoundlib.h>

//#define OVERREAD
#define INFINITE

int main(int argc, char* argv[]) {
#ifndef INFINITE
	long loops = 1; // playback loop times
#endif	
	int bytes_per_sample = 0 ;
	int channels_num = 2 ;
	int playback_format = 0 ;

	int rc;
	int size; // period_size = frames per period * 4 bytes
	snd_pcm_uframes_t frames; // frames per period	
	int buffer_periods = 16; // number of periods per buffer
	char *buffer;
	
	snd_pcm_t *handle;
	char *pcm_name;
	
	snd_pcm_hw_params_t *params;
	unsigned int val;
	int dir;

	unsigned int flag;
	signed short fd;  // file descriptor
	
	unsigned int samplerate = 32000 ;
	char *file_name = "/tmp/test.pcm";

	pcm_name = strdup("hw:0,0");
	while ((flag=getopt(argc, argv, "t:f:d:r:f:"))!=-1) 
	{
		switch (flag) 
		{
 		case 't': // type(format)
		   	switch (optarg[0])
      			{
              			case 'p'://pcm
	                      		playback_format = 0 ;
                      			break;
              			case 'u'://u-law
        		              	playback_format = 1 ;
		                      	break;
			        case 'a'://a-law
                		      	playback_format = 2 ;
                      		      	break;
              			default:
                      			playback_format = 0 ;
      			}
      			break;

		case 'd': // device
			/* Open PCM device for playing (playback). */
			switch (optarg[0]) 
			{
			case '0':
				pcm_name = strdup("hw:0,0");
				break;
			case '1':
				pcm_name = strdup("hw:0,1");
				break;
			default:
				pcm_name = strdup("hw:0,0");
			}
		break;
		case 'r':
			samplerate = (unsigned int)atoi(optarg);
			break;
		case 'f':
			file_name = optarg;
			break;			
		default:
			break;
		}
	}

	/* Open PCM device for playback. */
	rc = snd_pcm_open(&handle, pcm_name, SND_PCM_STREAM_PLAYBACK, 0);
	if (rc < 0) 
	{
		fprintf(stderr, 	"unable to open pcm device: %s\n", snd_strerror(rc));
		exit(1);
	}

	/* Open output file */
	fd = open(file_name, O_RDONLY);
	if (fd < 0) 
	{
		fprintf(stderr, "unable to open file: %s\n", snd_strerror(rc));
		exit(1);
	}
	/* Allocate a hardware parameters object. */
	snd_pcm_hw_params_alloca(&params);

	/* Fill it in with default values. */
	snd_pcm_hw_params_any(handle, params);
  
	/* Set the desired hardware parameters. */
	/* Interleaved mode */
	snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);

	/* Signed 16-bit little-endian format */
	if(playback_format == 0) {
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_S16_LE);
		bytes_per_sample = 2 ;
	}
	else if(playback_format == 1) {
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_MU_LAW);
		bytes_per_sample = 1 ;
	}
	else {
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_A_LAW);
		bytes_per_sample = 1 ;
	}

	/* Two channels (stereo) */
	snd_pcm_hw_params_set_channels(handle, params, channels_num);

	/* Sampling rate (read from standard input parameters) */
	val = samplerate;
	dir = 0;
	snd_pcm_hw_params_set_rate_near(handle, params, &val, &dir);

	/* Set period size to 32 frames. */
	frames = 512;
	snd_pcm_hw_params_set_period_size_near(handle, params, &frames, &dir);
	/* Write the parameters to the driver */
	rc = snd_pcm_hw_params(handle, params);
	if (rc < 0) 
	{
		fprintf(stderr, "unable to set hw parameters: %s\n", snd_strerror(rc));
		exit(1);
	}

	/* Memory Allocate App Buffer */
	size = frames * bytes_per_sample * channels_num ; /* 2 bytes/sample, 2 channels */
	buffer = (char *) malloc(size*buffer_periods);

	printf("size*buffer_periods = %d\n", size*buffer_periods) ;
#ifdef INFINITE
	while (1)
#else
	while (loops)
#endif	
	{
#ifndef INFINITE
		loops--;
#endif
		int frames_num = frames*buffer_periods ;

		rc = read(fd, buffer, size*buffer_periods);
		if (rc == 0) 
		{
			fprintf(stderr, "end of file on input\n");
			break;
		} 
		else if (rc != size*buffer_periods) 
		{
			fprintf(stderr, 	"short read: read %d bytes\n", rc);
			int frame_size = bytes_per_sample * channels_num ;
			frames_num = rc / frame_size ;
		}

		rc = snd_pcm_writei(handle, buffer, frames_num);
		if (rc == -EPIPE) 
		{
			/* EPIPE means underrun */
			fprintf(stderr, "underrun occurred\n");
			snd_pcm_prepare(handle);
		} 
		else if (rc < 0) 
		{
			fprintf(stderr, "error from writei: %s\n",
			snd_strerror(rc));
		}  
		else if (rc != (int)frames*buffer_periods) 
		{
			fprintf(stderr, "short write, write %d frames\n", rc);
		}
#ifdef OVERREAD
		lseek(fd, 0L, SEEK_SET);		
#endif
	}
	snd_pcm_drain(handle);
	snd_pcm_close(handle);
	free(buffer);
	close(fd);
	
	return 0;
}
