/*

This example reads standard from input and writes
to the default PCM device for 5 seconds of data.

*/



int main(int argc, char* argv[]) {
	unsigned char *buffer;

	signed short input_fd;  // file descriptor
	signed short output_fd;  // file descriptor
	
	char *input_name = "/tmp/test.pcm";
	char *output_name = "/tmp/out.pcm" ;

	while ((flag=getopt(argc, argv, "o:i:"))!=-1) 
	{
		switch (flag) 
		{
			case 'i':
				input_name = optarg ;
				break;			
			case 'o':
				output_name = optarg ;
			default:
				break;
		}
	}

	input_fd = open(input_name, O_RDONLY);
	if (input_fd < 0) 
	{
		printf("[ERR] Open input file failed!\n") ;
		exit(1);
	}
	
	output_fd = open(output_name,  O_RDWR | O_CREAT );
	if (output_fd < 0) 
	{
		printf("[ERR] Open output file failed!\n") ;
		exit(1);
	}

	fseek(input_fd, 0, SEEK_END);
	int input_size = ftell(input_fd) ;
	rewind(input_fd) ;

	buffer = (unsigned char *)malloc(sizeof(unsigned char) * input_size * 2) ;

	while (loops)
	{
		rc = read(fd, buffer, size*buffer_periods);
		if (rc == 0) 
		{
			fprintf(stderr, "end of file on input\n");
			break;
		} 
		else if (rc != size*buffer_periods) 
		{
			fprintf(stderr, 	"short read: read %d bytes\n", rc);
		}
		rc = snd_pcm_writei(handle, buffer, frames*buffer_periods);
		if (rc == -EPIPE) 
		{
			/* EPIPE means underrun */
			fprintf(stderr, "underrun occurred\n");
			snd_pcm_prepare(handle);
		} 
		else if (rc < 0) 
		{
			fprintf(stderr, "error from writei: %s\n",
			snd_strerror(rc));
		}  
		else if (rc != (int)frames*buffer_periods) 
		{
			fprintf(stderr, "short write, write %d frames\n", rc);
		}
	}
	
	close(fd);
	
	return 0;
}
