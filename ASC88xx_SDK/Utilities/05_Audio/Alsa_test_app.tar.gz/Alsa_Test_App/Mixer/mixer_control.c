/*

This example reads standard from input and writes
to the default PCM device for 5 seconds of data.

*/

#include <alsa/asoundlib.h>

#define TW2866  0
#define WAU8822 1
#define SSM2603 2
#define WM8978 3
#define CAT6011 4
#define NVP1114A 5
#define AIC3104 6
#define ALC5623 7

#define CODECTYPE NVP1114A


int set_control(const char* item, long val)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	snd_ctl_elem_value_set_integer(control, 0, val);//ctrl#0
	snd_hctl_elem_write(elem, control);

	snd_hctl_close(hctl);
}

//write same value to two int elements
int set_control_double_r(const char* item, long val)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	snd_ctl_elem_value_set_integer(control, 0, val);//ctrl#0
	snd_ctl_elem_value_set_integer(control, 1, val);//ctrl#0
	snd_hctl_elem_write(elem, control);

	snd_hctl_close(hctl);
}


int get_control(const char* item)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;

	int result = -1 ;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	if(snd_hctl_elem_read(elem, control) < 0)
		return -1 ;
	result = snd_ctl_elem_value_get_integer(control,0) ;

	snd_hctl_close(hctl);

	return result ;
}

int set_capturevol_control(const char* item, long dev, int channel, int vol)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	snd_ctl_elem_value_set_integer(control, 0, dev);
	snd_ctl_elem_value_set_integer(control, 1, channel);
	snd_ctl_elem_value_set_integer(control, 2, vol);
	snd_hctl_elem_write(elem, control);

	snd_hctl_close(hctl);
}

int get_capturevol_control(const char* item, int dev, int channel)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;

	int result = -1 ;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	int val = 1 ;
	snd_ctl_elem_value_set_integer(control, 0, dev);
	snd_ctl_elem_value_set_integer(control, 1, channel);
	if(snd_hctl_elem_read(elem, control) < 0)
		return -1 ;

	result = snd_ctl_elem_value_get_integer(control,0) ;

	snd_hctl_close(hctl);

	return result ;
}

#define PLAYBACK_CONNECT 1
#define PLAYBACK_DISCONNECT 0
int set_playbackselect_control(const char* item, int output, int connect)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	snd_ctl_elem_value_set_integer(control, 0, output);
	snd_ctl_elem_value_set_integer(control, 1, connect);
	snd_hctl_elem_write(elem, control);

	snd_hctl_close(hctl);
}

int get_playbackselect_control(const char* item, int output)
{
	snd_hctl_t *hctl;
	snd_ctl_elem_id_t *id;
	snd_hctl_elem_t *elem;
	snd_ctl_elem_value_t *control;

	int result = -1 ;
	
	snd_hctl_open(&hctl, "hw:0", 0);
	snd_hctl_load(hctl);	

	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_id_set_interface(id, SND_CTL_ELEM_IFACE_MIXER);
	snd_ctl_elem_id_set_name(id, item);//or snd_ctl_elem_id_set_id(id, numeric_id)

	elem = snd_hctl_find_elem(hctl, id);

	snd_ctl_elem_value_alloca(&control);
	snd_ctl_elem_value_set_id(control, id);    

	int val = 1 ;
	snd_ctl_elem_value_set_integer(control, 0, output);
	if(snd_hctl_elem_read(elem, control) < 0)
		return -1 ;

	result = snd_ctl_elem_value_get_integer(control,0) ;

	snd_hctl_close(hctl);

	return result ;
}


int main(int argc, char* argv[]) 
{
#if (CODECTYPE == TW2866)
	unsigned int flag;

	int capture_operation = -1 ;
	int playback_operation = -1 ;
	
	int caputre_device = -1 ;
	int capture_channel = -1 ;
	int capture_volume = -1 ;

	int playback_volume = -1 ;
	int playback_ch_selection = -1 ;
	int playback_ch_disselection = -1 ;

	while ((flag=getopt(argc, argv, "d:c:v:p:n:f:h"))!=-1)
        {
                switch (flag)
                {
			case 'd': // which codec Device
				caputre_device = (unsigned int)atoi(optarg);
				capture_operation = 1 ;
				break;

			case 'c': // which capture Channel
				capture_channel =  (unsigned int)atoi(optarg);
				capture_operation = 1 ;
				break;
				
			case 'v': // capture Volume
        	                capture_volume = (unsigned int)atoi(optarg);
				capture_operation = 1 ;
                	        break;

	                case 'p': // Playback-volume
        	                playback_volume = (unsigned int)atoi(optarg);
				playback_operation = 1 ;
	        	        break;

	                case 'n': // turn oN the mux of one playback channel 
        	                playback_ch_selection = (unsigned int)atoi(optarg);
				playback_operation = 1 ;
                	        break;

			case 'f': // turn oFf the mux connection of one playback channel
				playback_ch_disselection = (unsigned int)atoi(optarg);
				playback_operation = 1 ;
				break;

			case 'h':
				printf("TW2866 AUDIO MIXER help..\n") ;
				printf("== CAPTURE PART ==\n") ;
				printf("The following capture options should be used TOGETHER!!\n") ;
				printf("  -d : choose a codec Device(0~1)\n") ;
				printf("  -c : choose a Channel(0~3) on this codec device.\n") ;
				printf("  -v : choose a Volume value(0~15) on this channel.\n") ;
				
				printf("== PLAYBACK PART ==\n") ;
				printf("You can use the following playback options individually!!\n") ;
				printf("  -p : adjust Playback volume(0~15)\n") ;
				printf("  -n : turn oN the mux of one playback channel\n") ;
				printf("  -f : turn oFf the mux connection of one playback channel\n") ;
				return 0 ;
	                default:
        	                break;
                }
        }

	//Mixer : "Capture Volume"
	if(capture_operation == 1) {
		if(caputre_device == -1) {
			printf("[MIXER-ERR] Please use \"-d\" to notify	a capture device(0~1)!!\n");		
			return -1 ;
		}

		if(capture_channel == -1) {
			printf("[MIXER-ERR] Please use \"-c\" to notify	a capture channel(0~3)!!\n");		
			return -1 ;
		}
		
		if(capture_volume == -1) {
			printf("[MIXER-ERR] Please use \"-c\" to notify	a capture volume(0~15)!!\n");		
			return -1 ;
		}

		//Set
		set_capturevol_control("Capture Volume", caputre_device, capture_channel, capture_volume);	//device#0, channel#0, volume=8
	
		////Get
		printf("The capture volume of dev#%d, capture channel#%d is %d\n", caputre_device, capture_channel, get_capturevol_control("Capture Volume", caputre_device, capture_channel))	;
	}

	if(playback_operation == 1) {
		//Mixer : "Playback Volume"
		if(playback_volume != -1) {
			//Set
			set_control("Playback Volume", playback_volume);	//set volume level of playback device to 15 
			//Get
			printf("The playback volume is %d\n", get_control("Playback Volume")) ;
		}
		
		//Mixer : "Playback Mux Select"
		if(playback_ch_selection != -1) {
			//Set
			set_playbackselect_control("Playback Mux Select", playback_ch_selection, PLAYBACK_CONNECT);
			//Get
			printf("Playback output #%d is connected!\n", playback_ch_selection) ;
		}
		
		//Mixer : "Playback Mux Select" -- dis-select
		if(playback_ch_disselection != -1) {
			//Set
			set_playbackselect_control("Playback Mux Select", playback_ch_disselection, PLAYBACK_DISCONNECT);
			//Get
			printf("Playback output #%d is dis-connected!\n", playback_ch_disselection) ;
		}
	}	

#elif (CODECTYPE == SSM2603)
	
	//= ssm2603 playback volume =
	//1 ~ 80 : normal
	//0 : mute
	set_control("Playback Volume", 80);	
	printf("Play Volume = %d\n", get_control("Playback Volume")) ;
	
	
	//= ssm2603 input selection =
	//0 : BYPASS, 1 : Line-in, 2 : Mic-in
	set_control("Input Selection", 1);
	printf("Input Selection = %d\n", get_control("Input Selection")) ;
	
	
	// ------------- LINE-IN ----------------
	//= ssm2603 capture volume =
	//1 ~ 46 : normal
	//0 : mute
	set_control("Capture Volume", 46);	
	printf("Capture Volume = %d\n", get_control("Capture Volume")) ;
	
	// ------------- MIC-IN ----------------
	//= ssm2603 Mic Mute =
	//0 : no mute, 1 : mute
	set_control("Mic Mute", 0);
	printf("Mic Mute = %d\n", get_control("Mic Mute")) ;
	
	//= ssm2603 Side-tone Ctrl =
	//0 : disable sidetone
	//1 ~ 4 : sidetone gain
	set_control("Side-tone Ctrl", 0);
	printf("Side-tone Ctrl = %d\n", get_control("Side-tone Ctrl")) ;

#elif (CODECTYPE == WAU8822)
	//0x100 ~ 0x1ff (bit#8 must be set!)
	set_control_double_r("Playback Volume", 0x1ff);//0x100 ~ 0x1ff (bit#8 must be set!)
	// Input Volume
	//  0 : Mute
	//  1 ~ 64 : -12dB ~ +35.25dB
	set_control_double_r("Input Volume", 64);
	// Input Boost
	// 0 : +  0dB
	// 1 : + 20dB
	set_control_double_r("Input Boost", 1);
	// Input Type
	// 0 : mic-in
	// 1 : line-in
	set_control("Input Type", 0);
	
#elif (CODECTYPE == WM8978)
	//0x100 ~ 0x1ff (bit#8 must be set!)
	set_control_double_r("Playback Volume", 0x1ff);
	// Input Volume
	//  0 : Mute
	//  1 ~ 64 : -12dB ~ +35.25dB
	set_control_double_r("Input Volume", 48);
	// Input Boost
	// 0 : +  0dB
	// 1 : + 20dB
	set_control_double_r("Input Boost", 1);
	// Input Type
	// 0 : mic-in
	// 1 : line-in
	set_control("Input Type", 0);
#elif (CODECTYPE == CAT6011)
	//= cat6011 capture volume =
	//1 ~ 3 : 1X, 2X, 4X enlarge
	//0 : mute
	set_control("Capture Volume", 0);	
	// Sample Rate
	// - The sample rate of CAT6011 codec cannot be configured manually.
	// - It will be regenerated according to the N/CTS/TMDS-Clock sent by HDMI source device.
	// - Please read the HDMI spec to get the information in advance.
	printf("Sample Rate = %d\n", get_control("Sample Rate")) ;
#elif (CODECTYPE == NVP1114A)
	unsigned int flag;

	int capture_operation = -1 ;
	int playback_operation = -1 ;
	
	int caputre_device = -1 ;
	int capture_channel = -1 ;
	int capture_volume = -1 ;

	int playback_volume = -1 ;

	while ((flag=getopt(argc, argv, "d:c:v:p:n:f:h"))!=-1)
        {
                switch (flag)
                {
			case 'd': // which codec Device
				caputre_device = (unsigned int)atoi(optarg);
				capture_operation = 1 ;
				break;

			case 'c': // which capture Channel
				capture_channel =  (unsigned int)atoi(optarg);
				capture_operation = 1 ;
				break;
				
			case 'v': // capture Volume
        	                capture_volume = (unsigned int)atoi(optarg);
				capture_operation = 1 ;
                	        break;

	                case 'p': // Playback-volume
        	                playback_volume = (unsigned int)atoi(optarg);
				playback_operation = 1 ;
	        	        break;

			case 'h':
				printf("NVP1114A AUDIO MIXER help..\n") ;
				printf("== CAPTURE PART ==\n") ;
				printf("The following capture options should be used TOGETHER!!\n") ;
				printf("  -d : choose a codec Device(0~1)\n") ;
				printf("  -c : choose a Channel(0~3) on this codec device.\n") ;
				printf("  -v : choose a Volume value(0~15) on this channel.\n") ;
				
				printf("== PLAYBACK PART ==\n") ;
				printf("  -p : adjust Playback volume(0~15)\n") ;
				return 0 ;
	                default:
        	                break;
                }
        }

	//Mixer : "Capture Volume"
	if(capture_operation == 1) {
		if(caputre_device == -1) {
			printf("[MIXER-ERR] Please use \"-d\" to notify	a capture device(0~1)!!\n");		
			return -1 ;
		}

		if(capture_channel == -1) {
			printf("[MIXER-ERR] Please use \"-c\" to notify	a capture channel(0~3)!!\n");		
			return -1 ;
		}
		
		if(capture_volume == -1) {
			printf("[MIXER-ERR] Please use \"-c\" to notify	a capture volume(0~15)!!\n");		
			return -1 ;
		}

		//Set
		set_capturevol_control("Capture Volume", caputre_device, capture_channel, capture_volume);	//device#0, channel#0, volume=8
	
		////Get
		printf("The capture volume of dev#%d, capture channel#%d is %d\n", caputre_device, capture_channel, get_capturevol_control("Capture Volume", caputre_device, capture_channel))	;
	}

	if(playback_operation == 1) {
		//Mixer : "Playback Volume"
		if(playback_volume != -1) {
			//Set
			set_control("Playback Volume", playback_volume);	//set volume level of playback device to 15 
			//Get
			printf("The playback volume is %d\n", get_control("Playback Volume")) ;
		}
	}	
#elif (CODECTYPE == AIC3104)
	// Playback Volume
	//  0 : Mute
	//  1 ~ 10 : 0dB, 1dB, ~, 9dB
	set_control("Playback Volume", 10);
        printf("Play Volume = %d\n", get_control("Playback Volume")) ;
	
	// Input Volume
	//  0 : Mute
	//  1 ~ 120 : 0dB, 0.5dB, 1dB, ~, 59.5dB
        set_control_double_r("Input Volume", 120);
        printf("Input Volume = %d\n", get_control("Input Volume")) ;
#elif (CODECTYPE == ALC5623)
	// Playback Volume
	//  0 : Mute
	//  1 ~ 32 : -34.5dB, -33dB, ~, +12dB
	set_control("Playback Volume", 0);
        printf("Play Volume = %d\n", get_control("Playback Volume")) ;
	
	// Input Volume
	//  0 : Mute
	//  1 ~ 32 : -16.5dB, -15dB, ~, +30dB
        //set_control_double_r("Input Volume", 1);
        //printf("Input Volume = %d\n", get_control("Input Volume")) ;


#endif

	return 0;
}
