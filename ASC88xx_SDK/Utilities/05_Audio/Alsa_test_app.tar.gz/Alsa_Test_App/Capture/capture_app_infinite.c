/*

This example reads from the default PCM device
and writes to standard output for 5 seconds of data.

*/

#include <alsa/asoundlib.h>

#define DEFAULT_CHANNELS_NUM 2

#define CODEC_CHIP_TW2866	0
#define CODEC_CHIP_SSM2603	1
#define CODEC_CHIP_WAU8822	2
#define	CODEC_CHIP_WM8978	3
#define CODEC_CHIP_NVP1114A	4
#define CODEC_CHIP_CAT6011	5
#define CODEC_CHIP_AIC3104	6
#define CODEC_CHIP_ALC5623	7

//default file name
#define CAPFILE0 "/tmp/test0_0.pcm"
#define CAPFILE1 "/tmp/test0_1.pcm"
#define CAPFILE2 "/tmp/test0_2.pcm"
#define CAPFILE3 "/tmp/test0_3.pcm"
#define DEVFILE "hw:0,0"

//#define INFINITE_TEST
#ifdef INFINITE_TEST
static int test_counter = 0 ;
#endif

void TW2866_capture_func(snd_pcm_t *handle, int buffer_size, snd_pcm_uframes_t frame_num_of_period, \
			int channel_number, int period_size, signed short fd0, signed short fd1, signed short fd2, signed short fd3)
{
	int rc ;
	int i ;
	
	char **buffers ;
	buffers = malloc(channel_number * sizeof(char**));
	for(i = 0 ; i < channel_number ; i++) {
		printf("buffer_size* channel_number = %d\n", buffer_size);
		buffers[i] = (char *) malloc(buffer_size);
		memset(buffers[i], 0, buffer_size) ;
	}

	while (1)
	{
		//printf("before snd_pcm_readn()\n") ;
		rc = snd_pcm_readn(handle, (void**)buffers, frame_num_of_period);
		//printf("after snd_pcm_readn()\n") ;
		if (rc == -EPIPE) 
		{
			/* EPIPE means overrun */
			fprintf(stderr, "overrun occurred\n");
			snd_pcm_prepare(handle);
		} 
		else if (rc < 0) 
		{
			fprintf(stderr,
			"error from read: %s\n",
			snd_strerror(rc));
		} 
		else if (rc != (int)frame_num_of_period) 
		{
			fprintf(stderr, "short read, read %d frames\n", rc);
		}

		//file#0
		rc = write(fd0, buffers[0], period_size / (channel_number));

		//file#1
		rc += write(fd1, buffers[1], period_size / channel_number) ;		

		if(channel_number == 4) {
			//file#2
			rc += write(fd2, buffers[2], period_size / channel_number);

			//file#3
			rc += write(fd3, buffers[3],  period_size / channel_number) ;		
		}

	}

	snd_pcm_drain(handle);
	snd_pcm_close(handle);
	for(i = 0 ; i < channel_number ; i++) {
		free(buffers[i]);
	}
	free(buffers) ;

	close(fd0);
	close(fd1);	
	if(channel_number == 4) {
		close(fd2);
		close(fd3);	
	}
	return ;
}

void NVP1114A_capture_func(snd_pcm_t *handle, int buffer_size, snd_pcm_uframes_t frame_num_of_period, \
			int channel_number, int period_size, signed short fd0, signed short fd1, signed short fd2, signed short fd3)
{
	return TW2866_capture_func(handle, buffer_size, frame_num_of_period, channel_number, period_size, fd0, fd1, fd2, fd3) ;
}

void SSM2603_capture_func(snd_pcm_t *handle, int buffer_size, int period_num_of_buffer, snd_pcm_uframes_t frame_num_of_period, int channel_number, int period_size, signed short fd)
{
	char *buffer ;
	buffer = (char *) malloc(buffer_size);
	int rc ;
#ifdef INFINITE_TEST	
	int loopnum = 10 ;
#endif
	while (1)
	{
		rc = snd_pcm_readi(handle, buffer, frame_num_of_period * period_num_of_buffer);

		if (rc == -EPIPE)
		{
			/* EPIPE means overrun */
			fprintf(stderr, "overrun occurred\n");
			snd_pcm_prepare(handle);
		}
		else if (rc < 0)
		{
			fprintf(stderr,	"error from read: %s\n",snd_strerror(rc));
		}
		else if (rc != (int) frame_num_of_period*period_num_of_buffer)
		{
			fprintf(stderr, "short read, read %d frames(should be %d)\n", rc, (int) frame_num_of_period*period_num_of_buffer);
		}

		rc = write(fd, buffer, buffer_size);
		if (rc != buffer_size)
		{
			fprintf(stderr, "short write: wrote %d bytes\n", rc);
		}

#ifdef INFINITE_TEST	
		loopnum-- ;
		if(loopnum < 0) {
			printf("#%d Capture ends\n", test_counter) ;
			loopnum = 10 ;
			lseek(fd, 0L, SEEK_SET);
			test_counter++ ;
			continue ;
		}
#endif		
	}
	snd_pcm_drain(handle);
	snd_pcm_close(handle);
	free(buffer);
	close(fd);

	return ;
}

void WAU8822_capture_func(snd_pcm_t *handle, int buffer_size, int period_num_of_buffer, snd_pcm_uframes_t frame_num_of_period, \
			int channel_number, int period_size, signed short fd) 
{
	SSM2603_capture_func(handle, buffer_size, period_num_of_buffer, frame_num_of_period, channel_number, period_size, fd) ;

}

void WM8978_capture_func(snd_pcm_t *handle, int buffer_size, int period_num_of_buffer, snd_pcm_uframes_t frame_num_of_period, int channel_number, int period_size, signed short fd) 
{
	SSM2603_capture_func(handle, buffer_size, period_num_of_buffer, frame_num_of_period, channel_number, period_size, fd) ;
}

void CAT6011_capture_func(snd_pcm_t *handle, int buffer_size, int period_num_of_buffer, snd_pcm_uframes_t frame_num_of_period, int channel_number, int period_size, signed short fd) 
{
	SSM2603_capture_func(handle, buffer_size, period_num_of_buffer, frame_num_of_period, channel_number, period_size, fd) ;
}

void AIC3104_capture_func(snd_pcm_t *handle, int buffer_size, int period_num_of_buffer, snd_pcm_uframes_t frame_num_of_period, \
			int channel_number, int period_size, signed short fd) 
{
	SSM2603_capture_func(handle, buffer_size, period_num_of_buffer, frame_num_of_period, channel_number, period_size, fd) ;

}

void ALC5623_capture_func(snd_pcm_t *handle, int buffer_size, int period_num_of_buffer, snd_pcm_uframes_t frame_num_of_period, \
			int channel_number, int period_size, signed short fd) 
{
	SSM2603_capture_func(handle, buffer_size, period_num_of_buffer, frame_num_of_period, channel_number, period_size, fd) ;

}


int main(int argc, char* argv[]) {
	int rc;

	int codec_chip = CODEC_CHIP_TW2866 ;

	//0 : PCM
	//1 : u-law
	//2 : a-law
	int capture_format = 0 ;

	int byte_num_of_sample   = 1 ;
	int sample_num_of_frame ;
	snd_pcm_uframes_t frame_num_of_period  = 512 ;
	int period_num_of_buffer = 32; // number of periods per buffer

	int sample_size ;
	int frame_size  ;
	int period_size ;
	int buffer_size ;

	snd_pcm_t *handle;
	char *pcm_name;

	snd_pcm_hw_params_t *params;
	unsigned int val;
	int dir;
	int channel_number = DEFAULT_CHANNELS_NUM ;
	int default_max_ch = 0 ;
	int default_min_ch = 0 ;
	int current_max_ch = 0 ;
	int current_min_ch = 0 ;
	unsigned int dummy = 0 ;

	unsigned int flag;
	signed short fd0 = 0, fd1 = 0, fd2 = 0, fd3 = 0;  // file descriptor
	
	unsigned int samplerate = 32000;
	char *file_name0 = CAPFILE0 ;
	char *file_name1 = CAPFILE1 ;
	char *file_name2 = CAPFILE2 ;
	char *file_name3 = CAPFILE3 ;

	pcm_name =  strdup(DEVFILE);
	while ((flag=getopt(argc, argv, "n:c:t:d:r:0:1:2:3:h"))!=-1) 
	{
		switch (flag) 
		{
			case 'c':
				switch (optarg[0]) 
				{
					case 't':
						codec_chip = CODEC_CHIP_TW2866 ;
						break;
					case 's':
						codec_chip = CODEC_CHIP_SSM2603 ;
						break;
					case 'a':
						codec_chip = CODEC_CHIP_WAU8822 ;
						break;
					case 'm':
						codec_chip = CODEC_CHIP_WM8978 ;
						break;
					case 'n':
						codec_chip = CODEC_CHIP_NVP1114A ;
						break;
					case 'c':
						codec_chip = CODEC_CHIP_CAT6011 ;
						break;
					case 'i':
						codec_chip = CODEC_CHIP_AIC3104 ;
						break;
					case 'l':
						codec_chip = CODEC_CHIP_ALC5623 ;
						break;


				}
				break;				
			case 'n':
				channel_number = (unsigned int)atoi(optarg);
				break ;
			case 't': // type(format)
				switch (optarg[0]) 
				{
					case 'p'://pcm
						capture_format = 0 ;
						break;
					case 'u'://u-law
						capture_format = 1 ;
						break;
					case 'a'://a-law
						capture_format = 2 ;
						break;
					default:
						capture_format = 0 ;
				}
				break;
			case 'd': // device
				  /* Open PCM device for recording (capture). */
				switch (optarg[0]) 
				{
					case '0':
						pcm_name = strdup("hw:0,0");
						break;
					case '1':
						pcm_name = strdup("hw:0,1");
						break;
					default:
						pcm_name = strdup("hw:0,0");
				}
				break;
			case 'r':
				samplerate = (unsigned int)atoi(optarg);
				break;
			case '0' :
				file_name0 = optarg ;						
				break;
			case '1' :
				file_name1 = optarg ;						
				break;
			case '2' :
				file_name2 = optarg ;						
				break;
			case '3' :
				file_name3 = optarg ;						
				break;
			case 'h' :
				printf(" -c : codec chip type,\n") ;
				printf("      this can be t(TW2866), s(SSM2603), a(WAU8822), m(WM8978), n(NVP1114A), c(CAT6011), i(AIC3104), l(ALC5623)\n");
				printf(" -n : channel number, this should be 2 or 4(only TW2866/NVP1114A supports 4).\n") ;
				printf(" -t : capture format, this can be p(PCM), u(u-Law), a(a-Law).\n") ;
				printf(" -d : capture device, this can be 0 or 1.\n") ;
				printf(" -r : capture sample rate, this can be 8000, 16000, 32000, 44100, 48000.\n") ;
				printf(" -0 : capture-channel#0 file name\n") ;
				printf(" -1 : capture-channel#1 file name\n") ;
				printf(" -2 : capture-channel#2 file name\n") ;
				printf(" -3 : capture-channel#3 file name\n") ;
				printf(" [EX]\n") ;
				printf("  If we hope to use capture-dev#0 to capture 4 channels audio, u-Law, 44100,\n") ;
				printf("  and write channel#0 data to /tmp/cap0.pcm, using TW2866/NVP1114A, the command will be\n") ;
				printf(" \"./capture_app_infinite -c t -n 4 -d 0 -t u -r 44100 -0 /tmp/cap0.pcm\"\n") ;
				return 0 ;
			default:
				break;
		}
	}

	if((codec_chip != CODEC_CHIP_TW2866) && (codec_chip != CODEC_CHIP_NVP1114A)) {
		if( channel_number != 2 ) {
			fprintf(stderr, "Wrong channel number!\n");
			exit(1) ;
		}
	}
	
	sample_num_of_frame  = channel_number ;
	
	if(capture_format == 0) {
		byte_num_of_sample = 2 ;
	}
	else {
		byte_num_of_sample = 1 ;
	}
	sample_size = byte_num_of_sample * 1 ;
	frame_size = sample_num_of_frame * sample_size ; 
	period_size = frame_num_of_period * frame_size ;
	buffer_size = period_num_of_buffer * period_size ;

	/* Open PCM device for playback. */
	rc = snd_pcm_open(&handle, pcm_name, SND_PCM_STREAM_CAPTURE, 0);
	if (rc < 0) 
	{
		fprintf(stderr,	"unable to open pcm device: %s\n", snd_strerror(rc));
		exit(1);
	}
	
	/* Open output file */
	fd0 = open(file_name0, O_RDWR | O_CREAT);
	if (fd0 < 0) 
	{
		fprintf(stderr, "unable to open file: %s\n", file_name0);
		exit(1);
	}
	
	fd1 = open(file_name1, O_RDWR | O_CREAT);	
	if (fd1 < 0) 
	{
		fprintf(stderr, "unable to open file: %s\n", file_name1);
		exit(1);
	}

	if(channel_number == 4) {
		fd2 = open(file_name2, O_RDWR | O_CREAT);	
		if (fd2 < 0) 
		{
			fprintf(stderr, "unable to open file: %s\n", file_name2);
			exit(1);
		}

		fd3 = open(file_name3, O_RDWR | O_CREAT);	
		if (fd3 < 0) 
		{
			fprintf(stderr, "3unable to open file: %s\n", file_name3);
			exit(1);
		}
	}

	/* Allocate a hardware parameters object. */
	snd_pcm_hw_params_alloca(&params);

	/* Fill it in with default values. */
	snd_pcm_hw_params_any(handle, params);
	default_max_ch = snd_pcm_hw_params_get_channels_max(params, &dummy) ;
	default_min_ch = snd_pcm_hw_params_get_channels_min(params, &dummy) ;
	printf("Default max channel of codec is %d, and min is %d.\n", default_max_ch, default_min_ch) ;
	printf("dummy = %d\n", dummy) ;

	/* Set the desired hardware parameters. */
	if((codec_chip == CODEC_CHIP_TW2866) || (codec_chip == CODEC_CHIP_NVP1114A))
		snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_NONINTERLEAVED);
	else
		snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);

	/* Signed 16-bit little-endian format */
	if(capture_format == 0) {
		printf("SND_PCM_FORMAT_S16_LE!\n");
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_S16_LE);
	}
	else if (capture_format == 1) {
		printf("SND_PCM_FORMAT_MU_LAW!\n") ;
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_MU_LAW);
	}
	else {
		printf("SND_PCM_FORMAT_A_LAW!\n") ;
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_A_LAW);
	}

	/* Setting channel number */
	snd_pcm_hw_params_set_channels(handle, params, channel_number);

	/* Sampling rate (read from standard input parameters) */
	val = samplerate;
	dir = 0;
	snd_pcm_hw_params_set_rate_near(handle, params, &val, &dir);
	
	/* Set period size to 32 frames. */
	snd_pcm_hw_params_set_period_size_near(handle, params, &frame_num_of_period, &dir);

	/* Write the parameters to the driver */
	rc = snd_pcm_hw_params(handle, params);
	if (rc < 0) 
	{
		fprintf(stderr, 	"unable to set hw parameters: %s\n", snd_strerror(rc));
		exit(1);
	}
	
	current_max_ch = snd_pcm_hw_params_get_channels_max(params, &dummy) ;
	current_min_ch = snd_pcm_hw_params_get_channels_min(params, &dummy) ;
	//printf("Current max channel of codec is %d, and min is %d.\n", current_max_ch, current_min_ch) ;	
	//printf("And they are both equal to channel_number(%d) after you call snd_pcm_hw_params() to assign channel number.\n", channel_number);

	switch(codec_chip) {
		case CODEC_CHIP_TW2866:
			TW2866_capture_func(handle, buffer_size, frame_num_of_period, channel_number, period_size, fd0, fd1, fd2, fd3);
			break ;
		case CODEC_CHIP_SSM2603:
			SSM2603_capture_func(handle, buffer_size, period_num_of_buffer ,frame_num_of_period, channel_number, period_size, fd0) ;
			break ;
		case CODEC_CHIP_WAU8822:
			WAU8822_capture_func(handle, buffer_size, period_num_of_buffer ,frame_num_of_period, channel_number, period_size, fd0) ;
			break ;
		case CODEC_CHIP_WM8978:
			WM8978_capture_func(handle, buffer_size, period_num_of_buffer ,frame_num_of_period, channel_number, period_size, fd0) ;
			break ;
		case CODEC_CHIP_NVP1114A:
			NVP1114A_capture_func(handle, buffer_size, frame_num_of_period, channel_number, period_size, fd0, fd1, fd2, fd3);
			break ;
		case CODEC_CHIP_CAT6011:
			CAT6011_capture_func(handle, buffer_size, period_num_of_buffer ,frame_num_of_period, channel_number, period_size, fd0) ;
			break ;
		case CODEC_CHIP_AIC3104:
			AIC3104_capture_func(handle, buffer_size, period_num_of_buffer ,frame_num_of_period, channel_number, period_size, fd0) ;
			break ;
		case CODEC_CHIP_ALC5623:
			ALC5623_capture_func(handle, buffer_size, period_num_of_buffer ,frame_num_of_period, channel_number, period_size, fd0) ;
			break ;



	} ;
  
	return 0;
}

