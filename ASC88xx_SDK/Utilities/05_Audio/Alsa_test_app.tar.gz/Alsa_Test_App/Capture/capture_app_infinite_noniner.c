/*

This example reads from the default PCM device
and writes to standard output for 5 seconds of data.

*/

#include <alsa/asoundlib.h>

#define CHANNELS_NUM 4

#define CARDNUM 0
#if (CARDNUM == 0)
#define CAPFILE0 "/tmp/test0_0.pcm"
#define CAPFILE1 "/tmp/test0_1.pcm"
#define CAPFILE2 "/tmp/test0_2.pcm"
#define CAPFILE3 "/tmp/test0_3.pcm"
#define CARDFILE "hw:0,0,0"
#else
#define CAPFILE0 "/tmp/test1_0.pcm"
#define CAPFILE1 "/tmp/test1_1.pcm"
#define CAPFILE2 "/tmp/test1_2.pcm"
#define CAPFILE3 "/tmp/test1_3.pcm"
#define CARDFILE "hw:0,1"
#endif

int main(int argc, char* argv[]) {
	int rc;

	int byte_num_of_sample   = 2 ;
	int sample_num_of_frame  = CHANNELS_NUM ;
	snd_pcm_uframes_t frame_num_of_period  = 512 ;
	int period_num_of_buffer = 32; // number of periods per buffer

	int sample_size = byte_num_of_sample * 1 ;
	int frame_size = sample_num_of_frame * sample_size ; 
	int period_size = frame_num_of_period * frame_size ;
	int buffer_size = period_num_of_buffer * period_size ;

	char *buffer; // app buffer
	char *buffer1;
	int original_buf_index ;
	int output_buf_index ;
	
	snd_pcm_t *handle;
	char *pcm_name;

	snd_pcm_hw_params_t *params;
	unsigned int val;
	int dir;

	unsigned int flag;
	signed short fd0, fd1, fd2, fd3;  // file descriptor
	
	unsigned int samplerate = 32000;
	char *path_name ;
	char *file_name0 = CAPFILE0 ;
	char *file_name1 = CAPFILE1 ;
	char *file_name2 = CAPFILE2 ;
	char *file_name3 = CAPFILE3 ;

	int i;

	pcm_name =  strdup(CARDFILE);
	while ((flag=getopt(argc, argv, "d:r:0:1:2:3:x"))!=-1) 
	{
		switch (flag) 
		{
			case 'd': // device
				  /* Open PCM device for recording (capture). */
				switch (optarg[0]) 
				{
				case '0':
					pcm_name = strdup("hw:0,0");
					break;
				case '1':
					pcm_name = strdup("hw:0,1");
					break;
				case '2':
					pcm_name = strdup("hw:0,2");
					break;
				case '3':
					pcm_name = strdup("hw:0,3");
					break;
				case '4':
					pcm_name = strdup("hw:0,4");
					break;					
				default:
					pcm_name = strdup("hw:0,0");
				}
				break;
			case 'r':
				samplerate = (unsigned int)atoi(optarg);
				break;
			case '0' :
				file_name0 = optarg ;						
				break;
			case '1' :
				file_name1 = optarg ;						
				break;
			case '2' :
				file_name2 = optarg ;						
				break;
			case '3' :
				printf("hello~ %s\n", optarg) ;
				file_name3 = optarg ;						
				break;
			default:
				break;
		}
	}

	/* Open PCM device for playback. */
	rc = snd_pcm_open(&handle, pcm_name, SND_PCM_STREAM_CAPTURE, 0);
	if (rc < 0) 
	{
		fprintf(stderr,	"unable to open pcm device: %s\n", snd_strerror(rc));
		exit(1);
	}
	
	/* Open output file */
	fd0 = open(file_name0, O_RDWR | O_CREAT);
	if (fd0 < 0) 
	{
		fprintf(stderr, "unable to open file: %s\n", file_name0);
		exit(1);
	}
	
	fd1 = open(file_name1, O_RDWR | O_CREAT);	
	if (fd1 < 0) 
	{
		fprintf(stderr, "unable to open file: %s\n", file_name1);
		exit(1);
	}
#if (CHANNELS_NUM == 4)
	fd2 = open(file_name2, O_RDWR | O_CREAT);	
	if (fd2 < 0) 
	{
		fprintf(stderr, "unable to open file: %s\n", file_name2);
		exit(1);
	}
	
	fd3 = open(file_name3, O_RDWR | O_CREAT);	
	if (fd3 < 0) 
	{
		fprintf(stderr, "3unable to open file: %s\n", file_name3);
		exit(1);
	}
#endif
	/* Allocate a hardware parameters object. */
	snd_pcm_hw_params_alloca(&params);

	/* Fill it in with default values. */
	snd_pcm_hw_params_any(handle, params);

	/* Set the desired hardware parameters. */
	snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_NONINTERLEAVED);

	/* Signed 16-bit little-endian format */
	snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_S16_LE);

	/* Two channels (stereo) */
	snd_pcm_hw_params_set_channels(handle, params, CHANNELS_NUM);

	/* Sampling rate (read from standard input parameters) */
	val = samplerate;
	dir = 0;
	snd_pcm_hw_params_set_rate_near(handle, params, &val, &dir);
	printf("cap rate = %d..\n", val);
	
	/* Set period size to 32 frames. */
	snd_pcm_hw_params_set_period_size_near(handle, params, &frame_num_of_period, &dir);

	/* Write the parameters to the driver */
	rc = snd_pcm_hw_params(handle, params);
	if (rc < 0) 
	{
		fprintf(stderr, 	"unable to set hw parameters: %s\n", snd_strerror(rc));
		exit(1);
	}

	char *buffers[4] ;
	for(i = 0 ; i < 4 ; i++) {
		printf("buffer_size* CHANNELS_NUM = %d\n", buffer_size);
		buffers[i] = (char *) malloc(buffer_size);
	}

	while (1)
	{
		rc = snd_pcm_readn(handle, (void**)buffers, frame_num_of_period);
		if (rc == -EPIPE) 
		{
			/* EPIPE means overrun */
			fprintf(stderr, "overrun occurred\n");
			snd_pcm_prepare(handle);
		} 
		else if (rc < 0) 
		{
			fprintf(stderr,
			"error from read: %s\n",
			snd_strerror(rc));
		} 
		else if (rc != (int)frame_num_of_period) 
		{
			fprintf(stderr, "short read, read %d frames\n", rc);
		}

		//file#0
		rc = write(fd0, buffers[0], period_size / (CHANNELS_NUM));

		//file#1
		rc += write(fd1, buffers[1], period_size / CHANNELS_NUM) ;		
#if (CHANNELS_NUM == 4)
		//file#2
		rc += write(fd2, buffers[2], period_size / CHANNELS_NUM);

		//file#3
		rc += write(fd3, buffers[3],  period_size / CHANNELS_NUM) ;		

#endif //TEST4CHANNELS		

/*		if (rc != period_size)
		{
			fprintf(stderr, "short write: we only wrote %d bytes(should be %d)\n", rc, period_size);
		}*/
#ifdef OVERWRITE			
		lseek(fd0, 0L, SEEK_SET);
#endif	
	}
	snd_pcm_drain(handle);
	snd_pcm_close(handle);
	for(i = 0 ; i < 4 ; i++) {
		free(buffers[i]);
	}
	close(fd0);
	close(fd1);	
#if (CHANNELS_NUM == 4)
	close(fd2);
	close(fd3);	
#endif
  
	return 0;
}

