#!/bin/sh
#Author : james.lin@VN.com 
#This script will help user to generate their own ALSA lib.
#The ${PWD}/shared_lib is the output directory.
#You can find libasound.so.* in that directory.
#

echo 1. Configure the ALSA Lib
./configure --host=arm-linux --prefix=${PWD}/shared_lib

echo 2. Replace the definition of macro ALSA_CONFIG_DIR of include/config.h
sed 's/\/share\/alsa/\/etc\/ALSA/g' include/config.h > test.h

echo 3. Make the project
make clean;make;make install


