#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int GetParam(FILE *pfInput)
{
    char acTmpText[200];
    int sdwRet;

    fscanf(pfInput, "%s", acTmpText);
    sdwRet = atoi(acTmpText);
    fgets(acTmpText, 200, pfInput);

    return sdwRet;
}
void getInHeight(char  *szSensorConfigFile, unsigned long *pdwVideoInWidth,unsigned long *pdwVideoInHeight)
{
 
		FILE 	*pfSensorCfgInput = NULL;
		unsigned long	dwIndex;
		unsigned long dwVideoInWidth=0 ;
		unsigned long dwVideoInHeight=0;
		
		// open sensor config file
	    if ((pfSensorCfgInput=fopen(szSensorConfigFile, "r")) == NULL) {
	        printf("Open sensor config file %s fail !!\n", szSensorConfigFile);
	        return;
	    }
		
		
		// ignore 12 fields
		for (dwIndex=0; dwIndex<12; dwIndex++) {
			GetParam(pfSensorCfgInput);
		}

		*pdwVideoInWidth = GetParam(pfSensorCfgInput);
		*pdwVideoInHeight = GetParam(pfSensorCfgInput);

		if (pfSensorCfgInput != NULL) {
			fclose(pfSensorCfgInput);
		}
	
	  return;
}

int main( int argc, char * argv[] )
{
  
  
  FILE * pFile;
  unsigned long height=0,width=0;
  unsigned char *buffer=NULL;
  unsigned long  count=0;
  unsigned char *tmp_buffer=NULL;
  unsigned long dwVideoSize=0,dwPhotoLDCTblSize=0;
  //height=getInHeight(argv[1]);

  //width=strtoul (argv[2],NULL,0);
   //height=strtoul (argv[1],NULL,0);
   
  getInHeight(argv[1], &width,&height);
  dwVideoSize = width*height;
    if (width <= 512)
    {
		dwPhotoLDCTblSize = dwVideoSize; // size of WORD
    }
    else if (width <= 1024)
    {
		dwPhotoLDCTblSize = dwVideoSize >> 1; // size of WORD
    }
    else if (width <= 2048)
    {
		dwPhotoLDCTblSize = dwVideoSize >> 2; // size of WORD
    }
    else
   {
	    dwPhotoLDCTblSize = dwVideoSize >> 3; // size of WORD
    }
    
  
  
  buffer=(unsigned char *)malloc(dwPhotoLDCTblSize*sizeof(unsigned short));
  tmp_buffer=buffer;
  memset(buffer,0x0,dwPhotoLDCTblSize*sizeof(unsigned short));
  count = dwPhotoLDCTblSize;
  while(count!=0)
  {
    
    *(unsigned short *)tmp_buffer=1024;
    tmp_buffer+=sizeof(unsigned short);
    //printf("%p %04x\n",tmp_buffer,*(unsigned short *)tmp_buffer);
    count--;
  }
  
  
  pFile = fopen ( argv[2] , "wb" );
  fwrite (buffer , 1 , dwPhotoLDCTblSize*sizeof(unsigned short) , pFile );
  fclose (pFile);
  return 0;
  
}


