#!/bin/sh

SENSOR_CFG_LIST="list.txt"
PHOTO_LDC_TBL_FILENAME="photo_ldc_tbl"
ls sensor_config/  >  $SENSOR_CFG_LIST





if [ -f ./gen_photometric_tbl ];then

rm -fr out


mkdir tmp
mkdir out


cat $SENSOR_CFG_LIST | \
while read filename; do
	  prefix_of_filename=`echo $filename | awk  -F'.' '{ print $1 }'`
	  sensorname=`echo $prefix_of_filename  | awk  -F'_' '{ print $1 }'`
	  resolution=`echo $prefix_of_filename  | awk  -F'_' '{ print $2 }'`
	  cap_sensorname=`echo $sensorname | tr  '[a-z]' '[A-Z]'`
	  #  echo "part:$filename prefix_of_filename:$prefix_of_filename cap_prefix_of_filename:$cap_prefix_of_filename"

	  
./gen_photometric_tbl  sensor_config/$filename tmp/photo_ldc_tbl_m1.dat
./gen_photometric_tbl  sensor_config/$filename tmp/photo_ldc_tbl_m2.dat
./gen_photometric_tbl  sensor_config/$filename tmp/photo_ldc_tbl_userdefine1.dat
./gen_photometric_tbl  sensor_config/$filename tmp/photo_ldc_tbl_userdefine2.dat

cd tmp/ >  /dev/null 2>&1

tar zcvf ../out/$cap_sensorname"_"$resolution"_"$PHOTO_LDC_TBL_FILENAME"."tar"."gz   *.dat > /dev/null 2>&1
rm -f *.dat

cd -  >  /dev/null 2>&1

	 
done 
rm -fr tmp


fi 


rm -f $SENSOR_CFG_LIST
